import cv2
import mediapipe as mp
import math
import numpy as np
import pyautogui
import time

# --- CONFIG ---
pyautogui.FAILSAFE = False 
pyautogui.PAUSE = 0
LETTERS = " ABCDEFGHIJKLMNOPQRSTUVWXYZ"
SYMBOLS = "1234567890.,!?;:@#&+-/*="
MOUSE_SENS = 2200 
DIAL_SMOOTH = 0.25 
PINCH_T = 0.06

# MediaPipe Setup
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.8, min_tracking_confidence=0.8)
mp_draw = mp.solutions.drawing_utils

# --- STATE ---
is_paused = False
is_mouse_mode = False
last_action_time = 0
smooth_idx = 0
prev_mouse_pos = None
selected_char = ""

# --- WINDOW INITIALIZATION (PIN TO TOP) ---
window_name = "AirControl Elite"
cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
# This is the magic line for Windows 11 pinning:
cv2.setWindowProperty(window_name, cv2.WND_PROP_TOPMOST, 1) 

def get_dist(p1, p2):
    return math.sqrt((p1.x - p2.x)**2 + (p1.y - p2.y)**2)

def is_fist(lms):
    tips = [8, 12, 16, 20]
    return all(get_dist(lms[t], lms[0]) < 0.18 for t in tips)

def is_palm_away(lms, label):
    if label == "Right": return lms[4].x > lms[17].x
    return lms[4].x < lms[17].x

cap = cv2.VideoCapture(0)

while cap.isOpened():
    success, frame = cap.read()
    if not success: break
    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape
    results = hands.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

    r_lms, l_lms = None, None
    
    # Draw a "Safe Zone" boundary box
    cv2.rectangle(frame, (50, 50), (w-50, h-50), (100, 100, 100), 1)

    if results.multi_hand_landmarks:
        for i, res in enumerate(results.multi_handedness):
            label = res.classification[0].label
            lm = results.multi_hand_landmarks[i].landmark
            if label == "Right": r_lms = lm
            if label == "Left": l_lms = lm
            
            # Change landmark color if near edge
            conn_color = (0, 255, 0)
            if any(p.x < 0.1 or p.x > 0.9 or p.y < 0.1 or p.y > 0.9 for p in lm):
                conn_color = (0, 0, 255) # Red for "Warning"

            mp_draw.draw_landmarks(frame, results.multi_hand_landmarks[i], 
                                  mp_hands.HAND_CONNECTIONS,
                                  mp_draw.DrawingSpec(color=conn_color, thickness=2, circle_radius=2))

    # 1. SYSTEM CONTROLS
    if r_lms and l_lms:
        if is_fist(r_lms) and is_fist(l_lms): break 
        if is_palm_away(r_lms, "Right") and is_palm_away(l_lms, "Left"):
            if time.time() - last_action_time > 1.0:
                is_paused = not is_paused
                last_action_time = time.time()

    if is_paused:
        cv2.putText(frame, "PAUSED", (w//2-100, h//2), 2, 3, (0,0,255), 5)
        cv2.imshow(window_name, frame)
        if cv2.waitKey(1) & 0xFF == ord('q'): break
        continue

    # 2. MODE SWITCH
    if l_lms and is_fist(l_lms) and time.time() - last_action_time > 1.2:
        is_mouse_mode = not is_mouse_mode
        last_action_time = time.time()
        prev_mouse_pos = None

    # 3. CORE LOGIC
    if not is_mouse_mode:
        # --- KEYBOARD MODE ---
        if r_lms:
            if is_palm_away(r_lms, "Right") and time.time() - last_action_time > 0.8:
                pyautogui.press('enter'); last_action_time = time.time()

            current_set = SYMBOLS if is_fist(r_lms) else LETTERS
            dy, dx = r_lms[9].y - r_lms[0].y, r_lms[9].x - r_lms[0].x
            deg = math.degrees(math.atan2(dy, dx)) 
            
            # Anti-clockwise rotation fix
            raw_val = -90 - deg
            norm_val = max(0, min(90, raw_val))
            
            target_idx = (norm_val / 90) * (len(current_set) - 1)
            smooth_idx = (DIAL_SMOOTH * target_idx) + ((1 - DIAL_SMOOTH) * smooth_idx)
            current_idx = int(round(smooth_idx))
            selected_char = current_set[current_idx]

            # UI ARC
            ui_center = (w - 50, h - 50)
            cv2.ellipse(frame, ui_center, (350, 350), 0, 180, 270, (40, 40, 40), 45)
            for i, char in enumerate(current_set):
                char_a = 270 - (i / (len(current_set)-1) * 90)
                tx, ty = int(ui_center[0] + 390 * math.cos(math.radians(char_a))), int(ui_center[1] + 390 * math.sin(math.radians(char_a)))
                if i == current_idx:
                    cv2.circle(frame, (tx, ty), 32, (0, 255, 0), -1)
                    cv2.putText(frame, char, (tx-12, ty+10), 1, 2.2, (255, 255, 255), 3)
                else:
                    cv2.putText(frame, char, (tx-5, ty+5), 1, 0.7, (200, 200, 200), 1)

        # Triggers
        if l_lms and time.time() - last_action_time > 0.35:
            if get_dist(l_lms[4], l_lms[8]) < PINCH_T: pyautogui.write(selected_char); last_action_time = time.time()
            elif get_dist(l_lms[4], l_lms[12]) < PINCH_T: pyautogui.press('space'); last_action_time = time.time()
            elif get_dist(l_lms[4], l_lms[20]) < PINCH_T: pyautogui.press('backspace'); last_action_time = time.time()

    else:
        # --- MOUSE MODE ---
        if r_lms:
            is_moving = get_dist(r_lms[8], r_lms[12]) < 0.07 
            curr_pos = (r_lms[8].x, r_lms[8].y)
            if is_moving:
                if prev_mouse_pos:
                    pyautogui.moveRel((curr_pos[0] - prev_mouse_pos[0]) * MOUSE_SENS, (curr_pos[1] - prev_mouse_pos[1]) * MOUSE_SENS)
                prev_mouse_pos = curr_pos
                cv2.circle(frame, (int(curr_pos[0]*w), int(curr_pos[1]*h)), 10, (0, 255, 0), -1)
            else:
                prev_mouse_pos = None
                if time.time() - last_action_time > 0.4:
                    if get_dist(r_lms[4], r_lms[8]) < PINCH_T: pyautogui.click(); last_action_time = time.time()
                    elif get_dist(r_lms[4], r_lms[12]) < PINCH_T: pyautogui.rightClick(); last_action_time = time.time()
            # Scroll
            if all(r_lms[t].y < r_lms[6].y for t in [8, 12, 16, 20]) and not is_moving:
                if prev_mouse_pos: pyautogui.scroll(int((prev_mouse_pos[1] - curr_pos[1]) * 40))
                prev_mouse_pos = curr_pos

    cv2.putText(frame, f"MODE: {'MOUSE' if is_mouse_mode else 'KEYBOARD'}", (20, 50), 1, 1.5, (255, 150, 0), 2)
    cv2.imshow(window_name, frame)
    if cv2.waitKey(1) & 0xFF == ord('q'): break

cap.release()
cv2.destroyAllWindows()