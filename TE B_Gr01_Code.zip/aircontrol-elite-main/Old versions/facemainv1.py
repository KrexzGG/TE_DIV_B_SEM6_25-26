import cv2
import mediapipe as mp
import math
import pyautogui
import time

# --- CONFIG ---
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0
NOSE_SENS = 3500      # Cursor speed
EYE_THRESH = 0.012    # AR threshold for closed eyes
MOUTH_OPEN_THRESH = 0.04 # Threshold for "Park" mode (Lip distance)

# Initialize Face Mesh
mp_face = mp.solutions.face_mesh
face_mesh = mp_face.FaceMesh(refine_landmarks=True, min_detection_confidence=0.8)

# --- STATE ---
is_paused = False
nose_prev = None

# Timers
l_start = r_start = both_start = None

window_name = "FaceControl Standalone"
cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
cv2.setWindowProperty(window_name, cv2.WND_PROP_TOPMOST, 1)

def get_dist(p1, p2):
    return math.sqrt((p1.x - p2.x)**2 + (p1.y - p2.y)**2)

cap = cv2.VideoCapture(0)

while cap.isOpened():
    success, frame = cap.read()
    if not success: break
    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape
    results = face_mesh.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    now = time.time()

    if results.multi_face_landmarks:
        f = results.multi_face_landmarks[0].landmark
        
        # --- LANDMARKS ---
        nose = f[1]
        l_eye_open = get_dist(f[386], f[374])
        r_eye_open = get_dist(f[159], f[145])
        
        # Mouth Opening (Distance between top and bottom inner lips)
        mouth_gap = get_dist(f[13], f[14]) 
        is_parked = mouth_gap > MOUTH_OPEN_THRESH

        # --- BLINK/PAUSE LOGIC ---
        l_closed = l_eye_open < EYE_THRESH
        r_closed = r_eye_open < EYE_THRESH

        if l_closed and r_closed:
            if both_start is None: both_start = now
            dur = now - both_start
            if dur > 3.0: 
                is_paused = not is_paused
                both_start = now
            elif dur > 1.0 and not is_paused:
                pyautogui.doubleClick()
                both_start = now
        else:
            both_start = None
            if not is_paused:
                # Left Click (1.5s Hold)
                if l_closed:
                    if l_start is None: l_start = now
                    if now - l_start > 1.5: 
                        pyautogui.click(button='left')
                        l_start = now
                else: l_start = None
                
                # Right Click (1.5s Hold)
                if r_closed:
                    if r_start is None: r_start = now
                    if now - r_start > 1.5: 
                        pyautogui.click(button='right')
                        r_start = now
                else: r_start = None

        # --- NOSE DRIVE ---
        if not is_paused and not is_parked:
            if nose_prev:
                dx = (nose.x - nose_prev[0]) * NOSE_SENS
                dy = (nose.y - nose_prev[1]) * NOSE_SENS
                pyautogui.moveRel(dx, dy)
            nose_prev = (nose.x, nose.y)
        else:
            # When parked or paused, reset anchor to avoid "jumps" when resuming
            nose_prev = (nose.x, nose.y)

        # --- UI VISUALS ---
        # Mouth Gap Meter (Yellow if parked, Green if active)
        meter_color = (0, 0, 255) if is_parked else (0, 255, 0)
        cv2.rectangle(frame, (20, h-40), (20 + int(mouth_gap*2000), h-20), meter_color, -1)
        cv2.putText(frame, "Mouth Opening", (20, h-50), 1, 1, (255, 255, 255), 1)
        
        # Blink Meters
        cv2.rectangle(frame, (w-120, h-40), (w-120 + int(l_eye_open*2000), h-30), (255, 255, 0), -1)
        cv2.rectangle(frame, (w-120, h-25), (w-120 + int(r_eye_open*2000), h-15), (255, 255, 0), -1)
        cv2.putText(frame, "Eyes", (w-120, h-50), 1, 1, (255, 255, 255), 1)

    # Status Overlay
    mode_text = "PAUSED" if is_paused else ("PARKED" if is_parked else "DRIVING")
    status_color = (0, 0, 255) if is_paused or is_parked else (0, 255, 0)
    cv2.putText(frame, f"STATUS: {mode_text}", (20, 50), 1, 2, status_color, 2)
    
    cv2.imshow(window_name, frame)
    if cv2.waitKey(1) & 0xFF == ord('q'): break

cap.release()
cv2.destroyAllWindows()