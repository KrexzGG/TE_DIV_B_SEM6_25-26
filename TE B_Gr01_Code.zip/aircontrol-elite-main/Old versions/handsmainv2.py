import cv2
import mediapipe as mp
import math
import numpy as np
import pyautogui
import time

# --- CONFIG ---
pyautogui.FAILSAFE = False 
pyautogui.PAUSE = 0
LETTERS = " ABCDEFGHIJKLMNOPQRSTUVWXYZ"
SYMBOLS = "1234567890.,!?;:@#&+-/*="
MOUSE_SENS = 2200 
DIAL_SMOOTH = 0.25 # Higher = more responsive, Lower = smoother
PINCH_T = 0.06

# MediaPipe Setup
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.8, min_tracking_confidence=0.8)
mp_draw = mp.solutions.drawing_utils

# --- STATE ---
is_paused = False
is_mouse_mode = False
last_action_time = 0
smooth_idx = 0
prev_mouse_pos = None
selected_char = ""

def get_dist(p1, p2):
    return math.sqrt((p1.x - p2.x)**2 + (p1.y - p2.y)**2)

def is_fist(lms):
    tips = [8, 12, 16, 20]
    return all(get_dist(lms[t], lms[0]) < 0.18 for t in tips)

def is_palm_away(lms, label):
    if label == "Right": return lms[4].x > lms[17].x
    return lms[4].x < lms[17].x

cap = cv2.VideoCapture(0)

while cap.isOpened():
    success, frame = cap.read()
    if not success: break
    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape
    results = hands.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

    r_lms, l_lms = None, None
    
    if results.multi_hand_landmarks:
        for i, res in enumerate(results.multi_handedness):
            label = res.classification[0].label
            lm = results.multi_hand_landmarks[i].landmark
            if label == "Right": r_lms = lm
            if label == "Left": l_lms = lm
            mp_draw.draw_landmarks(frame, results.multi_hand_landmarks[i], mp_hands.HAND_CONNECTIONS)

    # 1. SYSTEM CONTROLS
    if r_lms and l_lms:
        if is_fist(r_lms) and is_fist(l_lms): break # Shutdown
        if is_palm_away(r_lms, "Right") and is_palm_away(l_lms, "Left"):
            if time.time() - last_action_time > 1.0:
                is_paused = not is_paused
                last_action_time = time.time()

    if is_paused:
        cv2.putText(frame, "PAUSED", (w//2-100, h//2), 2, 3, (0,0,255), 5)
        cv2.imshow("AirControl Elite", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'): break
        continue

    # 2. MODE SWITCH
    if l_lms and is_fist(l_lms) and time.time() - last_action_time > 1.2:
        is_mouse_mode = not is_mouse_mode
        last_action_time = time.time()
        prev_mouse_pos = None

    # 3. CORE LOGIC
    if not is_mouse_mode:
        # --- KEYBOARD MODE ---
        if r_lms:
            # RETURN KEY: Back of right hand
            if is_palm_away(r_lms, "Right") and time.time() - last_action_time > 0.8:
                pyautogui.press('enter'); last_action_time = time.time()

            current_set = SYMBOLS if is_fist(r_lms) else LETTERS
            
            # DIAL MATH:
            # Wrist(0) to Middle MCP(9)
            dy = r_lms[9].y - r_lms[0].y
            dx = r_lms[9].x - r_lms[0].x
            deg = math.degrees(math.atan2(dy, dx)) # Vertical is ~ -90
            
            # Normalize: Vertical Up (-90) = 0, Tilt Left (-180) = 90
            # This ensures anti-clockwise hand tilt = increasing list index
            raw_val = -90 - deg
            norm_val = max(0, min(90, raw_val))
            
            # Smooth the INDEX directly for better UI feel
            target_idx = (norm_val / 90) * (len(current_set) - 1)
            smooth_idx = (DIAL_SMOOTH * target_idx) + ((1 - DIAL_SMOOTH) * smooth_idx)
            current_idx = int(round(smooth_idx))
            selected_char = current_set[current_idx]

            # UI ARC (Bottom Right Corner)
            ui_center = (w - 50, h - 50)
            cv2.ellipse(frame, ui_center, (350, 350), 0, 180, 270, (50, 50, 50), 40)
            
            for i, char in enumerate(current_set):
                # 270 deg is TOP, 180 deg is LEFT. 
                # As i increases, angle decreases from 270 to 180.
                char_a = 270 - (i / (len(current_set)-1) * 90)
                tx = int(ui_center[0] + 390 * math.cos(math.radians(char_a)))
                ty = int(ui_center[1] + 390 * math.sin(math.radians(char_a)))
                
                if i == current_idx:
                    cv2.circle(frame, (tx, ty), 30, (0, 255, 0), -1)
                    cv2.putText(frame, char, (tx-12, ty+10), 1, 2, (255, 255, 255), 3)
                else:
                    cv2.putText(frame, char, (tx-5, ty+5), 1, 0.7, (200, 200, 200), 1)

        # Left Hand Triggers
        if l_lms and time.time() - last_action_time > 0.35:
            if get_dist(l_lms[4], l_lms[8]) < PINCH_T: # Type
                pyautogui.write(selected_char); last_action_time = time.time()
            elif get_dist(l_lms[4], l_lms[12]) < PINCH_T: # Space
                pyautogui.press('space'); last_action_time = time.time()
            elif get_dist(l_lms[4], l_lms[20]) < PINCH_T: # Backspace
                pyautogui.press('backspace'); last_action_time = time.time()

    else:
        # --- SCISSORS MOUSE MODE ---
        if r_lms:
            # MOVEMENT: Index and Middle distance threshold
            scissors_dist = get_dist(r_lms[8], r_lms[12])
            is_moving = scissors_dist < 0.07 # Wider for comfort
            curr_pos = (r_lms[8].x, r_lms[8].y)

            if is_moving:
                if prev_mouse_pos:
                    dx = (curr_pos[0] - prev_mouse_pos[0]) * MOUSE_SENS
                    dy = (curr_pos[1] - prev_mouse_pos[1]) * MOUSE_SENS
                    pyautogui.moveRel(dx, dy)
                prev_mouse_pos = curr_pos
                cv2.circle(frame, (int(curr_pos[0]*w), int(curr_pos[1]*h)), 10, (0, 255, 0), -1)
            else:
                prev_mouse_pos = None # "Clutch" out
                
                # Clicks (While parked)
                if time.time() - last_action_time > 0.4:
                    if get_dist(r_lms[4], r_lms[8]) < PINCH_T: # Left
                        pyautogui.click(); last_action_time = time.time()
                    elif get_dist(r_lms[4], r_lms[12]) < PINCH_T: # Right
                        pyautogui.rightClick(); last_action_time = time.time()

            # SCROLL: All 4 fingers extended Up
            tips = [r_lms[8], r_lms[12], r_lms[16], r_lms[20]]
            if all(t.y < r_lms[6].y for t in tips) and not is_moving:
                if prev_mouse_pos:
                    s_dy = (prev_mouse_pos[1] - curr_pos[1]) * 40
                    pyautogui.scroll(int(s_dy))
                prev_mouse_pos = curr_pos

    cv2.putText(frame, f"MODE: {'MOUSE' if is_mouse_mode else 'KEYBOARD'}", (20, 50), 1, 1.5, (255, 150, 0), 2)
    cv2.imshow("AirControl Elite", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'): break

cap.release()
cv2.destroyAllWindows()