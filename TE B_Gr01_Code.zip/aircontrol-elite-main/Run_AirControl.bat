@echo off
:: Change this to the folder where your project is
cd /d "C:\Users\shrey_r7of\OneDrive\Desktop\HandControllerProject"

:: Run the launcher using the venv python directly
.venv\Scripts\python.exe launcher.py

pause