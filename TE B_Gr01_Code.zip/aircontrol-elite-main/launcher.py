import os
import subprocess
import sys

def launch():
    # Detect the path to the python interpreter inside your virtual environment
    if os.name == 'nt':  # Windows
        venv_python = os.path.join(".venv", "Scripts", "python.exe")
    else:  # Mac/Linux
        venv_python = os.path.join(".venv", "bin", "python")

    # Check if venv exists
    if not os.path.exists(venv_python):
        print(f"Error: Could not find virtual environment at {venv_python}")
        input("Press Enter to exit...")
        return

    print("========================================")
    print("      AIRCONTROL MASTER LAUNCHER        ")
    print("========================================")
    print("1. Hand Gestures (Keyboard & Mouse)")
    print("2. Face Gestures (Nose Drive & Blinks)")
    print("3. Exit")
    print("----------------------------------------")
    
    choice = input("Select an option (1-3): ")

    if choice == '1':
        print("\nStarting Hand Controller...")
        subprocess.run([venv_python, "handsmain.py"])
    elif choice == '2':
        print("\nStarting Face Controller...")
        subprocess.run([venv_python, "facemain.py"])
    elif choice == '3':
        print("Exiting...")
        sys.exit()
    else:
        print("Invalid choice. Try again.")
        launch()

if __name__ == "__main__":
    launch()