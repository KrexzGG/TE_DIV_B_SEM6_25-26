import cv2
import mediapipe as mp
import math
import pyautogui
import time
import sys

# --- CONFIG ---
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0
NOSE_SENS = 3800
SMOOTHING = 0.15      
DEADZONE = 0.0015     
EYE_THRESH = 0.016    # Slightly more lenient for easier clicking
MOUTH_OPEN_THRESH = 0.045 
CONFIRM_BLINK_TIME = 1.2  

# Initialize Models
mp_face = mp.solutions.face_mesh
face_mesh = mp_face.FaceMesh(refine_landmarks=True, min_detection_confidence=0.8)

# --- STATE ---
is_paused = False
is_prompt_active = False
is_mouth_open = False # Pre-defined to prevent NameError
nose_prev = None
smooth_move = [0, 0]

# Independent Timers
mouth_open_start = None
l_click_start = r_click_start = both_click_start = None
prompt_l_start = prompt_r_start = None

window_name = "FaceControl Elite"
cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
cv2.setWindowProperty(window_name, cv2.WND_PROP_TOPMOST, 1)

def get_dist(p1, p2):
    return math.sqrt((p1.x - p2.x)**2 + (p1.y - p2.y)**2)

cap = cv2.VideoCapture(0)

while cap.isOpened():
    success, frame = cap.read()
    if not success: break
    frame = cv2.flip(frame, 1) 
    h, w, _ = frame.shape
    results = face_mesh.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    now = time.time()

    # Reset per-frame state
    is_mouth_open = False 

    if results.multi_face_landmarks:
        f = results.multi_face_landmarks[0].landmark
        nose = f[1]
        
        # MIRROR FIX: l_eye is screen-left (physical right), r_eye is screen-right (physical left)
        l_eye_dist = get_dist(f[159], f[145]) 
        r_eye_dist = get_dist(f[386], f[374]) 
        
        l_closed = l_eye_dist < EYE_THRESH
        r_closed = r_eye_dist < EYE_THRESH

        # 1. MOUTH CLUTCH
        mouth_gap = get_dist(f[13], f[14]) 
        is_mouth_open = mouth_gap > MOUTH_OPEN_THRESH

        # 2. PROMPT LOGIC
        if is_prompt_active:
            overlay = frame.copy()
            cv2.rectangle(overlay, (0, 0), (w, h), (20, 20, 20), -1)
            frame = cv2.addWeighted(overlay, 0.8, frame, 0.2, 0)
            
            cv2.putText(frame, "SYSTEM TIMEOUT", (w//2-140, h//2-60), 1, 2, (0, 0, 255), 2)
            cv2.putText(frame, "BLINK LEFT: EXIT", (w//2-180, h//2), 1, 1.5, (255, 255, 255), 2)
            cv2.putText(frame, "BLINK RIGHT: CONTINUE", (w//2-180, h//2+40), 1, 1.5, (255, 255, 255), 2)

            if l_closed:
                if prompt_l_start is None: prompt_l_start = now
                prog = min(1.0, (now - prompt_l_start) / CONFIRM_BLINK_TIME)
                cv2.rectangle(frame, (w//2-180, h//2+10), (w//2-180 + int(prog*300), h//2+15), (0, 0, 255), -1)
                if prog >= 1.0: sys.exit()
            else: prompt_l_start = None

            if r_closed:
                if prompt_r_start is None: prompt_r_start = now
                prog = min(1.0, (now - prompt_r_start) / CONFIRM_BLINK_TIME)
                cv2.rectangle(frame, (w//2-180, h//2+50), (w//2-180 + int(prog*300), h//2+55), (0, 255, 0), -1)
                if prog >= 1.0: 
                    is_prompt_active = False
                    prompt_r_start = None
            else: prompt_r_start = None

        # 3. DRIVING LOGIC
        else:
            if l_closed and r_closed:
                if both_click_start is None: both_click_start = now
                if now - both_click_start > 0.8: pyautogui.doubleClick(); both_click_start = now
            else:
                both_click_start = None
                if l_closed:
                    if l_click_start is None: l_click_start = now
                    if now - l_click_start > 1.2: pyautogui.click(button='left'); l_click_start = now
                else: l_click_start = None
                if r_closed:
                    if r_click_start is None: r_click_start = now
                    if now - r_click_start > 1.2: pyautogui.click(button='right'); r_click_start = now
                else: r_click_start = None

            if not is_mouth_open:
                if nose_prev:
                    raw_dx = (nose.x - nose_prev[0])
                    raw_dy = (nose.y - nose_prev[1])
                    if abs(raw_dx) < DEADZONE: raw_dx = 0
                    if abs(raw_dy) < DEADZONE: raw_dy = 0
                    smooth_move[0] = (smooth_move[0] * (1 - SMOOTHING)) + (raw_dx * SMOOTHING)
                    smooth_move[1] = (smooth_move[1] * (1 - SMOOTHING)) + (raw_dy * SMOOTHING)
                    pyautogui.moveRel(smooth_move[0] * NOSE_SENS, smooth_move[1] * NOSE_SENS)
                nose_prev = (nose.x, nose.y)
                mouth_open_start = None
            else:
                nose_prev = (nose.x, nose.y)
                if mouth_open_start is None: mouth_open_start = now
                prog = min(1.0, (now - mouth_open_start) / 10.0)
                cv2.rectangle(frame, (20, h-40), (20 + int(prog*(w-40)), h-20), (0, 165, 255), -1)
                if prog >= 1.0: is_prompt_active = True

    # --- UI STATUS (Fixed Scope) ---
    if not is_prompt_active:
        status = "PARKED (CLUTCH)" if is_mouth_open else "DRIVING"
        color = (0, 0, 255) if is_mouth_open else (0, 255, 0)
        cv2.putText(frame, status, (20, 50), 1, 2, color, 2)
    
    cv2.imshow(window_name, frame)
    if cv2.waitKey(1) & 0xFF == ord('q'): break

cap.release()
cv2.destroyAllWindows()