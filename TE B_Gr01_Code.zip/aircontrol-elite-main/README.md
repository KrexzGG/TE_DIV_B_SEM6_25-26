# 🚀 AirControl Elite: Hybrid Gesture Interface

AirControl Elite is a high-performance, touchless interface system. It combines **Hand Tracking** for complex input and **Face Mesh** for hands-free navigation, allowing full computer control without a physical mouse or keyboard.

## 🛠 Quick Start
1.  Connect your webcam.
2.  Run `Run_AirControl.bat` from your desktop.
3.  Choose your mode in the launcher.

---

## 🖐 Mode 1: Hand Gestures (`handsmain.py`)
Optimized for typing and precise clicking.

### **Keyboard Mode**
* **Alphabet Dial:** Rotate your **Right Hand** (index finger up) to cycle through A-Z.
* **Symbols/Digits:** Make a **Fist** with your **Right Hand** to switch the dial to numbers and symbols.
* **Type Character:** Pinch **Left Index + Thumb**.
* **Space:** Pinch **Left Middle + Thumb**.
* **Backspace:** Pinch **Left Pinky + Thumb**.
* **Enter:** Show **Right Palm** to the camera.

### **Mouse Mode**
* **Toggle Mode:** Hold **Left Fist** for 1.2 seconds.
* **Move Cursor:** Bring **Right Index & Middle** together (Scissors) and move.
* **Left Click:** Pinch **Right Index + Thumb**.
* **Right Click:** Pinch **Right Middle + Thumb**.

---

## 🎭 Mode 2: Face Gestures (`facemain.py`)
Optimized for effortless navigation and "clutched" movement.

### **The Controls**
* **Nose Drive:** Move your **Nose** to drive the cursor relative to your head position.
* **The Clutch (Park):** **Open your mouth** to freeze the cursor. This allows you to look around or rest your neck.
* **Clicks:** * **Left Click:** Close **Left Eye** (1.2s).
    * **Right Click:** Close **Right Eye** (1.2s).
    * **Double Click:** Close **Both Eyes** (0.8s).

### **The Security Gate (10s Timeout)**
If your mouth remains open for 10 seconds, the system enters a safety prompt:
* **Blink Left:** Exit App.
* **Blink Right:** Resume Operation.

---

## 📸 Visual Guide

### **System Interface**
**The Master Launcher** ![Launcher Menu](Pictures/launcher.png)

**Keyboard: Alphabet Dial** ![Alphabet Dial](Pictures/alphabet%20typing.png)

**Keyboard: Digits & Symbols** ![Digits and Symbols](Pictures/digits%20and%20symbols%20typing.png)

**Hand Mouse Mode** ![Hand Mouse Mode](Pictures/mouse%20mode.png)

**Pause State** ![Pause Operation](Pictures/pause%20operation.png)

---

### **Face Navigation**
**Nose Drive (Moving)** ![Face Mouse Moving](Pictures/face%20mouse%20moving.png)

**The Clutch (Mouth Open / Parked)** ![Face Mouse Clutched](Pictures/face%20mouse%20clutched.png)

---

### **Safety & Exit**
**The 10-Second Timeout Choice** ![System Exit Choice](Pictures/system%20exit%20choice.png)

**Exit Confirmation** ![Exit Dialogue](Pictures/system%20exit%20dialogue.png)
